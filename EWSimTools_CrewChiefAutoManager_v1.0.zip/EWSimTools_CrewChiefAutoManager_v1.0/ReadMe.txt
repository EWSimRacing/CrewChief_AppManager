==============================================
EWSimTools: Crew Chief Auto Manager v1.0
Developed by Elliott Williams
www.instagram.com/ewsimracing
==============================================

This tool automatically starts and closes Crew Chief when you run supported racing sims...

Installation:

1. Unzip this folder anywhere on your PC (e.g., C:\CrewChiefAutoManager)
2. Double-click `Install.bat`
3. Accept the prompt to allow PowerShell to make changes

Done! Crew Chief will now start and stop automatically when you race.

---

Uninstall Instructions

To remove CrewChief Auto Manager from your system:

1. Go to the folder where you unzipped the tool
2. Double-click `Uninstall.bat`
3. Approve the admin prompt
4. The scheduled task and log file will be removed automatically

That’s it. You can now delete the folder if you no longer need it.

==============================================
Tool by EWSimRacing – Building tools for the sim racing community.
Follow updates: www.instagram.com/ewsimracing
==============================================

